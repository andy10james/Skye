﻿var windows = {};
windows.properties = {};
windows.internal = {};
windows.internal.f = {};
windows.internal.cw = {};
windows.maxedWindows = [];
windows.allWindows = [];
windows.load = function (enclosure, animation_ms) {
    windows.properties.enclosure = $(enclosure);
    windows.properties.anims = animation_ms;
    $(window).mouseup(windows.internal.f.globalMouseUp);
    $(window).mousemove(windows.internal.f.globalMouseMove);
    $(window).resize(windows.internal.f.globalResize);
};
windows.openWindow = function(title, top, left, width, height, hide, maximise, close, icon) {
    var window, tb, tb_title, tb_hide, tb_maximise, tb_close, tb_icon;
    window = $('<div/>', { class: 'window', id: windows.internal.guid() });
    window.css({ top: top, left: left, width: width, height: height });
    tb = $('<div/>', { class: 'tb' }).appendTo(window);
    if (icon) tb_icon = $('<img/>', { class: 'icon', src: icon }).appendTo(tb);
    if (close) tb_close = $('<div/>', { class: 'close' }).appendTo(tb);
    if (maximise) tb_maximise = $('<div/>', { class: 'maximise' }).appendTo(tb);
    if (hide) tb_hide = $('<div/>', { class: 'hide' }).appendTo(tb);
    tb_title = $('<div/>', { class: 'title', text: title }).appendTo(tb);
    $('<div/>', { class: 'clear' }).appendTo(tb);
    $('<div/>', { class: 'content' }).appendTo(window);
    if (close) tb_close.click(windows.internal.f.wintbCloseClick);
    if (maximise) tb_maximise.click(windows.internal.f.wintbMaxClick);
    tb.mousedown(windows.internal.f.wintbMouseDown);
    window.mousedown(windows.internal.f.winMouseDown);
    window.hide().appendTo(windows.properties.enclosure);
    windows.allWindows.push(window);
    windows.bringToFront(window);
    window.fadeIn(windows.properties.anims);
};
windows.max = function (win, imi) {
    /*var anims = windows.properties.anims;
    if (imi == true) anims = 0;*/
    win.stop();
    win.find("> .tb > .maximise").removeClass("maximise").addClass("restore");
    win.data("res-t", win.offset().top);
    win.data("res-l", win.offset().left);
    win.data("res-w", win.width());
    win.data("res-h", win.height());
    windows.internal.animateToMax(win);
    if (!windows.isMaxedWindow(win))
        windows.maxedWindows.push(win);
};
windows.res = function (win) {
    win.find("> .tb > .restore").removeClass("restore").addClass("maximise");
    win.animate({
        top: win.data("res-t"),
        left: win.data("res-l"),
        width: win.data("res-w"),
        height: win.data("res-h")
    }, windows.properties.anims);
    win.data("res-t", null);
    win.data("res-l", null);
    win.data("res-w", null);
    win.data("res-h", null);
    windows.internal.removeMaxedWindow(win);
};
windows.close = function (win) {
    win.fadeOut(
        windows.properties.anims,
        function () {
            $(this).remove();
            windows.internal.removeWindow($(this));
        });
};
windows.bringToFront = function (win) {
    var winIndex = win.css('z-index') - 1;
    $(windows.allWindows).each(function (i) {
        var curIndex = $(this).css('z-index');
        if ($(this).css('z-index') > winIndex)
            $(this).css({ 'z-index': curIndex - 1 });
    });
    win.css({ 'z-index': windows.allWindows.length });
};
windows.isMaxedWindow = function (win) {
    for (var i = 0; i < windows.maxedWindows.length; i++)
        if (windows.maxedWindows[i].is(win))
            return true;
    return false;
};
windows.internal.f.wintbMouseDown = function(e) {
    var sw = $(this).parents(".window");
    var swot = sw.offset();
    windows.internal.cw.cw = sw;
    windows.internal.cw.cl = e.pageX - swot.left;
    windows.internal.cw.ct = e.pageY - swot.top;
};
windows.internal.f.winMouseDown = function(e) {
    windows.bringToFront($(this));
};
windows.internal.f.wintbCloseClick = function (e) {
    var win = $(this).parents(".window");
    windows.close(win);
};
windows.internal.f.wintbMaxClick = function (e) {
    var win = $(this).parents('.window');
    if (windows.isMaxedWindow(win)) windows.res(win);
    else windows.max(win);
};
windows.internal.f.globalMouseUp = function () {
    windows.internal.cw = {};
};
windows.internal.f.globalMouseMove = function (e) {
    if (windows.internal.cw != null) {
        $(windows.internal.cw.cw).css({
            top: e.pageY - windows.internal.cw.ct,
            left: e.pageX - windows.internal.cw.cl,
            position: 'absolute'
        });
    }
};
windows.internal.f.globalResize = function (e) {
    for (var i = 0; i < windows.maxedWindows.length; i++)
        windows.internal.animateToMax(windows.maxedWindows[i]);
};
windows.internal.animateToMax = function (win) {
    win.stop();
    win.animate({
        top: windows.properties.enclosure.offset().top,
        left: windows.properties.enclosure.offset().left,
        width: windows.properties.enclosure.width() - parseInt(win.css("border-left-width")) - parseInt(win.css("border-right-width"))
        - parseInt(win.css("padding-left")) - parseInt(win.css("padding-right")),
        height: windows.properties.enclosure.height() - parseInt(win.css("border-top-width")) - parseInt(win.css("border-bottom-width"))
        - parseInt(win.css("padding-top")) - parseInt(win.css("padding-top")),
    }, windows.properties.anims);
};
windows.internal.removeMaxedWindow = function (win) {
    for (var i = 0; i < windows.maxedWindows.length; i++)
        if (windows.maxedWindows[i].is(win))
            windows.maxedWindows.splice(i, 1);
};
windows.internal.removeWindow = function (win) {
    windows.internal.removeMaxedWindow(win);
    for (var i = 0; i < windows.allWindows.length; i++)
        if (windows.allWindows[i].is(win))
            windows.allWindows.splice(i, 1);
};
windows.internal.guid = function() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
};